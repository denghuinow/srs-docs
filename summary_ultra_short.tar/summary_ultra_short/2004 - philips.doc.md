# Ultra Short Summary
- Platform-i MSN is an MHP-based instant messenger application for TV that enables real-time communication and presence features.
- MVP points: Login with existing Passport account, display and update buddy status, send and receive text messages, and show incoming message notifications.
- Key constraints: Must use MSNPv8 protocol, cannot create new Passport accounts, and input is limited to remote control and possibly wireless keyboard.
- Major risks/undecided issues: Not mentioned