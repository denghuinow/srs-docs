# Ultra Short Summary
A digital radio system based on GSM standards to ensure interoperability for European railway mobile communications, supporting voice and data for ground-train and ground-based personnel.

- **MVP points**: Supports telephony, emergency calls, voice group/broadcast services, and railway-specific functional addressing; provides coverage for voice and non-safety data with 95% probability at specified field strengths; includes enhanced multi-level precedence and pre-emption for call priority management; enables location-dependent addressing and shunting mode operations.
- **Key constraints**: Operates in the Railway GSM (R-GSM) frequency band (876–880 MHz uplink, 921–925 MHz downlink); requires interoperability across national borders with consistent numbering and subscriber management; must achieve call setup times as defined with authentication and ciphering enabled.
- **Major risks/undecided issues**: Not mentioned.