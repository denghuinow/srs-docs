# Ultra Short Summary

The Virtual Company Dossier (VCD) provides interoperable solutions for economic operators to electronically submit pre-existing company information as evidence of qualification to public sector awarding entities across EU Member States during public procurement procedures.

- **MVP points**: Enable cross-border electronic submission of qualification documents; support mapping between national attestations and EU selection/exclusion criteria; allow economic operators to compile and submit VCD packages; ensure contracting authorities can electronically receive and interpret VCDs.
- **Key constraints**: Must comply with Directive 2004/18/EC Articles 45-50; must accommodate different national evidence requirements and maturity levels; must ensure mutual recognition of qualification documents across borders.
- **Major risks**: Legal interoperability challenges between Member States; varying levels of digital readiness and evidence availability across countries.