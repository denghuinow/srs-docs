# Ultra Short Summary
A website to attract Oregon high school students to pursue computer science degrees at Oregon University System campuses.

- Provide career and personal information from CS professionals
- Display CS course information from OUS campuses
- Offer timely information with Q&A to encourage return visits
- Include calls to action and preparation plans for CS careers

- Limited availability of Chancellor's Office resources
- Must maintain teen-friendly design and navigation
- Must adhere to OUS website standards and conventions

- Not mentioned
- Not mentioned