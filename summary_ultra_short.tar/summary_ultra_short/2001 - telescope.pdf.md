# Ultra Short Summary

The X-Ray Telescope Control Processor flight software autonomously controls the Swift XRT instrument to collect, process, and transmit GRB science data and housekeeping telemetry to the spacecraft.

- **MVP points**
  - Process science data from the CCD camera and relay it to the Spacecraft Control Unit as CCSDS Source Packets.
  - Receive and execute commands from the SCU to set instrument state and camera mode.
  - Transmit detailed housekeeping data to the SCU and synchronize the local clock with the spacecraft time.
  - Control heaters on the telescope tube and thermal baffles, and read the Telescope Alignment Monitor.

- **Key constraints**
  - The TDRSS downlink bandwidth is limited to 1 kbps for housekeeping telemetry.
  - Real-time housekeeping packets must be limited to 230 bytes or less.
  - The ground system (ITOS) cannot reassemble segmented packets or decompress data.

- **Major risks/undecided issues**
  - Some science data acquisition modes and associated requirements are TBD/TBR.
  - Not mentioned.