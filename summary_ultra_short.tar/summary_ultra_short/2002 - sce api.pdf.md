# Ultra Short Summary
A standard C/C++ modeling interface for emulators and verification platforms, enabling communication between software models and hardware DUTs.

- **MVP points**: Provides multiple message channels between software models and hardware DUTs; supports untimed software models interfacing with RTL/gate-level DUTs; includes clock control for freezing DUT time during transactor operations; offers both C++ and C APIs for software-side access.
- **Key constraints**: Not intended for event-based or sub-cycle accurate simulation bridging; optimized for SystemC compatibility; requires frequent calls to the service loop function for message processing.
- **Major risks**: Not mentioned.